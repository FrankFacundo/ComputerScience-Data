# LLM

```bash
curl -X POST "http://localhost:30101/generate" \
    -d '{"prompt": "Hello everyone. How are you?"}' \
    -H "Content-type: application/json" -N 
```
