from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional
import io
import uvicorn
import asyncio

app = FastAPI()

class ChatRequest(BaseModel):
    prompt: str


@app.post("/generate")
async def create_chat_completion(chat_request: ChatRequest):
    if not chat_request.prompt:
        raise HTTPException(status_code=400, detail="Prompt is required")

    # Stream the response word by word
    async def stream_response_word_by_word(prompt: str):
        words = prompt.split()  # Split the prompt into words
        for word in words:
            print(word)
            yield word.encode('utf-8') + b' '  # Add a space after each word
            await asyncio.sleep(0.5)  # Introduce a small delay to simulate streaming

    return StreamingResponse(stream_response_word_by_word(chat_request.prompt), media_type="text/plain")

if __name__ == '__main__':
    uvicorn.run(
        app,
        host='0.0.0.0',
        port=30101,
        log_level="debug"
    )
