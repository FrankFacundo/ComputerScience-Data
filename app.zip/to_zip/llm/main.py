from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional
import io
import uvicorn
import asyncio
from mistral import Mistral

app = FastAPI()
mistral = Mistral()

class ChatRequest(BaseModel):
    prompt: str


@app.post("/generate")
async def create_chat_completion(chat_request: ChatRequest):
    if not chat_request.prompt:
        raise HTTPException(status_code=400, detail="Prompt is required")

    text_stream = mistral.generate(chat_request.prompt)
    return StreamingResponse(text_stream)
    # return StreamingResponse(text_stream, media_type="text/plain")

if __name__ == '__main__':
    uvicorn.run(
        app,
        host='0.0.0.0',
        port=30101,
        log_level="debug"
    )
