import os

class PdfTools():
    def __init__(self) -> None:
        pass
    
    def list_files(self):
        docs_path = os.path.join(os.path.dirname(__file__), 'docs')
        pdf_files = [f for f in os.listdir(docs_path) if f.endswith('.pdf')]
        files = {"Finance": pdf_files}
        return files

