import os

import streamlit as st
from components.sidebar import sidebar
# from s3 import S3
from pdf_tools import PdfTools

sidebar()
bucket_name = "classgpt"
pdf_tools = PdfTools()
all_classes = pdf_tools.list_files()

tab1, tab2 = st.tabs(["Upload data", "Delete"])

with tab1:
    st.subheader("Upload new lectures")

    chosen_class = st.selectbox(
        "Select a class",
        list(all_classes.keys()) + ["--"],
        index=len(all_classes),
    )

    if chosen_class != "--":
        with st.form("upload_pdf"):
            uploaded_files = st.file_uploader(
                "Upload a PDF file", type="pdf", accept_multiple_files=True
            )

            submit_button = st.form_submit_button("Upload")

            if submit_button:
                if len(uploaded_files) == 0:
                    st.error("Please upload at least one file")
                else:
                    with st.spinner(f"Uploading {len(uploaded_files)} files..."):
                        for uploaded_file in uploaded_files:
                            # Save the file inside the "docs" directory
                            file_path = os.path.join("app", "docs", uploaded_file.name)
                            with open(file_path, "wb") as f:
                                f.write(uploaded_file.getbuffer())
                        st.success(f"{len(uploaded_files)} files uploaded")


with tab2:
    st.subheader("Delete a class or a PDF file")

    chosen_class = st.selectbox(
        "Select a class to delete",
        list(all_classes.keys()) + ["--"],
        index=len(all_classes),
    )

    if chosen_class != "--":
        all_pdfs = all_classes[chosen_class]

        # Remove empty values
        all_pdfs = [x for x in all_pdfs if x]

        chosen_pdf = st.selectbox(
            "Select a PDF file to delete the whole class",
            all_pdfs + ["--"],
            index=len(all_pdfs),
        )

        if chosen_pdf != "--":
            submit_button = st.button("Remove")

            if submit_button:
                file_path = os.path.join("app", "docs", chosen_pdf)
                if os.path.exists(file_path):
                    os.remove(file_path)
                    st.success(f"{chosen_pdf} removed")
                else:
                    st.error(f"File {chosen_pdf} does not exist")
